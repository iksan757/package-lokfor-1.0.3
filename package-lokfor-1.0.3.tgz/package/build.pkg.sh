# Script Pembuat Paket .deb Tuan Muda

NAME="lokfor"
VERSION="1.0.3"
BUILD_DIR="pkg_build"

echo "📦 Memulai proses pengemasan $NAME v$VERSION..."

# 1. Bersihkan folder lama & buat struktur baru
rm -rf $BUILD_DIR
mkdir -p $BUILD_DIR/DEBIAN
mkdir -p $BUILD_DIR/data/data/com.termux/files/usr/bin
mkdir -p $BUILD_DIR/data/data/com.termux/files/usr/lib/$NAME

# 2. Buat file CONTROL (KTP Paket)
cat <<EOF > $BUILD_DIR/DEBIAN/control
Package: $NAME
Version: $VERSION
Architecture: all
Maintainer: iksan757
Description: Makes it easy for you to find files and folders, whatever they are, and whatever you write, enjoy by me Tuan-Muda - Termux Edition
EOF

# 3. Copy file bot Tuan Muda (kecuali folder build)
cp -r ./* $BUILD_DIR/data/data/com.termux/files/usr/lib/$NAME/
rm -rf $BUILD_DIR/data/data/com.termux/files/usr/lib/$NAME/$BUILD_DIR

# 4. Buat perintah eksekusi agar tinggal ketik 'lokfor'
cat <<EOF > $BUILD_DIR/data/data/com.termux/files/usr/bin/$NAME
#!/bin/bash
node /data/data/com.termux/files/usr/lib/$NAME/index.js
EOF

chmod +x $BUILD_DIR/data/data/com.termux/files/usr/bin/$NAME

# 5. Bungkus jadi .deb
dpkg-deb --build $BUILD_DIR ${NAME}_${VERSION}.deb

echo "✅ SELESAI! File kamu adalah: ${NAME}_${VERSION}.deb"
echo "Ketik 'pkg install ./${NAME}_${VERSION}.deb' untuk mencoba."


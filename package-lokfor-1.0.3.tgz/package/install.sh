#!/usr/bin/env bash

# --- WARNA ---
GREEN='\033[1;32m'
YELLOW='\033[1;33m'
CYAN='\033[1;36m'
NC='\033[0m'

# --- CEK DEPENDENSI SISTEM ---
if ! command -v ag &> /dev/null; then
    echo -e "\033[1;31m❌ Error: silversearcher-ag belum terinstal!\033[0m"
    echo -e "\033[1;33mSilakan instal terlebih dahulu:\033[0m"
    echo -e "Termux : pkg install silversearcher-ag"
    echo -e "Linux  : sudo apt install silversearcher-ag"
    exit 1
fi


echo -e "${CYAN}🛠  Memulai Proses Instalasi lokfor...${NC}"

# 1. Tentukan Jalur Binari
if [ -d "$PREFIX/bin" ]; then
    # Jika di Termux
    TARGET_DIR="$PREFIX/bin"
else
    # Jika di Linux Biasa
    TARGET_DIR="/usr/local/bin"
fi

# 2. Cek apakah folder bin proyek ada
if [ ! -f "bin/lokfor" ]; then
    echo -e "${RED}❌ Error: File bin/lokfor tidak ditemukan di folder ini!${NC}"
    exit 1
fi

# 3. Proses Pemindahan & Izin
echo -e "${YELLOW}📦 Menyalin mantra ke $TARGET_DIR...${NC}"
cp bin/lokfor "$TARGET_DIR/lokfor" 2>/dev/null || sudo cp bin/lokfor "$TARGET_DIR/lokfor"

echo -e "${YELLOW}🔑 Memberikan izin eksekusi...${NC}"
chmod +x "$TARGET_DIR/lokfor" 2>/dev/null || sudo chmod +x "$TARGET_DIR/lokfor"

# 4. Verifikasi
if command -v lokfor &> /dev/null; then
    echo -e "${GREEN}✅ Instalasi Berhasil!${NC}"
    echo -e "${CYAN}🚀 Sekarang kamu bisa mengetik 'lokfor' di mana saja.${NC}"
else
    echo -e "${RED}❌ Terjadi kesalahan saat instalasi.${NC}"
fi

